// db.js
var mongoose = require('mongoose');
mongoose.connect('mongodb://Shambre:Sham1616@ds119490.mlab.com:19490/my-library');
// mongodb://<dbuser>:<dbpassword>@ds153948.mlab.com:53948/practice_db
