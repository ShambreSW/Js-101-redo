// db.js
var mongoose = require('mongoose');
mongoose.connect('{insert connection string from mlabs}');
